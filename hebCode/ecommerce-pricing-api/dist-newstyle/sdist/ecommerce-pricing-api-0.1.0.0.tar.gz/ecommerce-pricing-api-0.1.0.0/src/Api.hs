{-# LANGUAGE DataKinds #-}
{-# LANGUAGE TemplateHaskell #-}
{-# LANGUAGE TypeOperators #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE DuplicateRecordFields     #-}

{-# LANGUAGE PolyKinds         #-}
{-# LANGUAGE TypeFamilies      #-}



module Api where



import GHC.Generics
import Data.Aeson
import Network.Wai
import Network.Wai.Handler.Warp
import Servant
import Control.Monad.Error
-- import Data.Swagger
import UnliftIO (SomeException, fromException)
import qualified Network.HTTP.Types as H
import Servant.Server
import Servant.Server.Internal.ErrorFormatter

import           Data.Proxy
import           Data.Text
import           Data.Semigroup


import           Data.String.Conversions
                 (cs)
import           Servant.API.ContentTypes


--Types for response body
data PriceLogics = PriceLogics
    {
         upc :: Integer
         , futureLogic  :: Logic
         , presentLogic :: Logic
         , historicalLogic :: [Logic]
    } deriving (Generic)

data Logic = Logic 
    {
        storeExceptions :: [StoreException]
        , zoneExceptions :: [ZoneException]
        , rule :: Rule
        , effective :: String

    } deriving (Generic)


data StoreException = StoreException
    {
        rule :: Rule
        ,store :: String
        ,zone :: String

    } deriving (Generic)

data ZoneException = ZoneException
    {
        rule :: Rule
        ,zone :: String
    } deriving (Generic)


data Rule = Rule 
    {
        adjustmentMethod :: String
        ,ignoreClearancePrice :: String
        ,noMarkupIfOnAd:: String
        ,markupBasisPoints :: Integer

    } deriving (Generic)


--types for response body

data UpdatedLogic = UpdatedLogic
    {
        upc :: Integer
        , futureLogic :: FutureLogic

    } deriving (Generic)

data FutureLogic = FutureLogic
    {
        storeExceptions :: [StoreException]
        , zoneExceptions :: [ZoneException]
        , rule :: Rule
        , effective :: String

    } deriving (Generic)

instance FromJSON UpdatedLogic
instance FromJSON FutureLogic
instance FromJSON StoreException
instance FromJSON Rule
instance FromJSON ZoneException


instance ToJSON PriceLogics
instance ToJSON Logic
instance ToJSON Rule
instance ToJSON ZoneException
instance ToJSON StoreException
instance ToJSON UpdatedLogic
instance ToJSON FutureLogic

--same response for all handlers
data ApiResponse a = ApiResponse{
                                 result::a
                                ,error::Maybe Int
                                ,code::Int
                                }deriving (Show,Generic)

instance (ToJSON a)=>ToJSON (ApiResponse a) 
-- instance (ToSchema a)=>ToSchema (ApiResponse a)

--API Type
type API = "upc"
            :> Capture "upc" Int
            :> Get '[JSON] (ApiResponse PriceLogics)
            :<|> "updatedlogic" 
            :> ReqBody '[JSON] UpdatedLogic
            :> Post '[JSON] (ApiResponse UpdatedLogic)


server :: Server API
server =  return getLogic :<|> return postLogic
          where 
            
                getLogic = throwError myerr

                postLogic = throwError myerr 
              
                myerr :: ServerError
                myerr = err503 { errBody = "Sorry dear user." }

customFormatters :: ErrorFormatters
customFormatters = defaultErrorFormatters
  { bodyParserErrorFormatter = customFormatter
  , urlParseErrorFormatter   = customFormatter
  , notFoundErrorFormatter   = notFoundFormatter
  }


customFormatter :: ErrorFormatter
customFormatter combntr req err = err400
    { errBody = encode body
    , errHeaders = [("Content-Type", "application/json")]
    }
  where
    body = object ["code".=(400::Int),"error".=err,"result".=Null]


notFoundFormatter :: NotFoundErrorFormatter
notFoundFormatter req = err404 { errBody = "Path not found" }

-- run 8080 app

startApp :: IO ()
startApp = do
    let settings =
                 setPort 8080 $
                 setOnExceptionResponse handleAllExceptions $
                 defaultSettings
    runSettings settings app

-- app :: Application
-- app = serve api server

app :: Application
app = serveWithContext
                api
                (customFormatters Servant.:. EmptyContext)
                server

api :: Proxy API
api = Proxy

handleAllExceptions :: SomeException -> Network.Wai.Response
handleAllExceptions e = responseLBS H.internalServerError500
                                [(H.hContentType, "application/json")]
                                (encode $ object ["code" .= (500 :: Int), "error".= ("Something went wrong" :: String), "result" .= Null])