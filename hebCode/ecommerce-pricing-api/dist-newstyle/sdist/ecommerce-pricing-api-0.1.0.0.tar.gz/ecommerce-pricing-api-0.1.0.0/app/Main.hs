module Main where

import Api

main :: IO ()
main = startApp
