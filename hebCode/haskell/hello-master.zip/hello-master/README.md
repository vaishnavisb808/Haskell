# hello

Example project for the [Haskell](http://haskellbook.com) book.
